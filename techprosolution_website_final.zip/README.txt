TECH PRO SOLUTION WEBSITE

Files:
- index.html: website content
- style.css: responsive styling
- script.js: mobile navigation and current year

PREVIEW:
Open index.html in a web browser.

BEFORE PUBLISHING:
1. Phone/WhatsApp and Kolkata service area have been added.
2. Business email and Kolkata, West Bengal service area are included. No street address is displayed.
3. Confirm which services you actually provide. Remove any service you do not offer.
4. The service list says land conversion (not land conversation); correct the wording if you meant a different service.
5. Do not describe the business as a government office or authorised centre unless that status is officially true.
6. Add your privacy policy and any legally required business details before collecting personal information.

FREE HOSTING:
You can publish this static site with GitHub Pages:
https://pages.github.com/
Create a GitHub repository, upload these three files to the repository root, then enable Pages in the repository's Settings. GitHub will provide a free github.io address.

DOMAIN:
www.techprosolution.com is a custom .com domain. Registering/renewing it normally costs money; free hosting does not make the domain itself free. You can start with the free GitHub Pages address and connect the .com domain later.
